import React, { useState, useEffect } from "react";
import EnvelopeGrid from "./components/EnvelopeGrid";
import ShareModal from "./components/ShareModal";
import { AnimatePresence } from "framer-motion";

const TARGET_DATE = new Date("2024-12-31T23:59:59Z");

const App = () => {
  const [shareData, setShareData] = useState(null);
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const tick = () => {
      const now = new Date().getTime();
      const diff = TARGET_DATE.getTime() - now;

      if (diff <= 0) return;

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor(
        (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-[420px] mx-auto px-4 overflow-x-hidden">
      <div className="text-center mt-6 mb-4">
        <h2 className="text-xl font-bold mb-2">Time Left</h2>
        <p className="text-lg font-semibold">
          {timeLeft.days}d {timeLeft.hours}h {timeLeft.minutes}m {timeLeft.seconds}s
        </p>
      </div>

      <EnvelopeGrid onShare={setShareData} />

      <AnimatePresence>
        {shareData && (
          <ShareModal
            key="share-modal"
            data={shareData}
            onClose={() => setShareData(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
